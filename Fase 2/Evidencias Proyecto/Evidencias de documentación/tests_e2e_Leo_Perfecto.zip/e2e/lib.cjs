const { chromium } = require('playwright')
const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url')
const exp = Math.floor(Date.now()/1000)+3600
const user = { id:'11111111-1111-1111-1111-111111111111', email:'ana@duocuc.cl', aud:'authenticated', role:'authenticated', user_metadata:{full_name:'Ana Prueba'}, app_metadata:{} }
const ses = { access_token:`${b64({alg:'HS256'})}.${b64({sub:user.id,exp,role:'authenticated'})}.x`, refresh_token:'r', token_type:'bearer', expires_in:3600, expires_at:exp, user }
exports.abrir = async (b, { rol='alumno', login=true, vp={width:390,height:844} }={}) => {
  await fetch('http://localhost:54321/__rol/'+rol)
  const ctx = await b.newContext({ viewport: vp, deviceScaleFactor: 2 })
  if (login) await ctx.addInitScript(s=>localStorage.setItem('sb-localhost-auth-token', JSON.stringify(s)), ses)
  await ctx.addInitScript(()=>{ try{ localStorage.setItem('leo-perfecto-sonidos','off'); localStorage.setItem('leo-perfecto-animaciones','off') }catch(e){} })
  const p = await ctx.newPage(); p.errs=[]; p.on('pageerror',e=>p.errs.push(e.message))
  return { ctx, p }
}
exports.chromium = chromium
