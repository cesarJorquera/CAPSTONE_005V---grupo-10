require('fs').mkdirSync('resultados',{recursive:true})
const { chromium, abrir } = require('./lib.cjs')
const U='http://localhost:8201', R=[]
const log = async()=> JSON.parse(await (await fetch('http://localhost:54321/__log')).text())
const reg=(id,ok,det)=>{R.push({id,ok,det}); console.log(id, ok?'OK':'FALLA', '|', det)}
const txt=async p=>(await p.innerText('body')).replace(/\s+/g,' ')
;(async()=>{
 const b = await chromium.launch(); let o
 // P-01 landing
 o=await abrir(b,{login:false}); await o.p.goto(U+'/'); await o.p.waitForTimeout(1500)
 let t=await txt(o.p); reg('P-01', new URL(o.p.url()).pathname==='/' && /Leo Perfecto/.test(t) && !o.p.errs.length, 'ruta '+new URL(o.p.url()).pathname+', errores de consola: '+o.p.errs.length)
 await o.p.screenshot({path:'resultados/p01_landing.png'}); await o.ctx.close()
 // P-02 protegida
 o=await abrir(b,{login:false}); await o.p.goto(U+'/inicio'); await o.p.waitForTimeout(1500); t=await txt(o.p)
 reg('P-02', new URL(o.p.url()).pathname==='/login' && /Google/.test(t) && /Autorizo/.test(t), 'redirige a '+new URL(o.p.url()).pathname+'; muestra botón Google y consentimiento')
 await o.p.screenshot({path:'resultados/p02_login.png'}); await o.ctx.close()
 // P-03 alumno inicio
 o=await abrir(b); await o.p.goto(U+'/inicio'); await o.p.waitForTimeout(1500); t=await txt(o.p)
 reg('P-03', new URL(o.p.url()).pathname==='/inicio' && /Hola, Ana/.test(t) && /0 de 7 pasos/.test(t), 'saludo con nombre y progreso 0 de 7')
 await o.p.screenshot({path:'resultados/p03_inicio.png'})
 // P-04 alumno no entra a docente
 await o.p.goto(U+'/docente'); await o.p.waitForTimeout(1200)
 reg('P-04', new URL(o.p.url()).pathname==='/inicio', 'alumno que abre /docente queda en '+new URL(o.p.url()).pathname); await o.ctx.close()
 // P-05 docente elegir espacio
 o=await abrir(b,{rol:'docente'}); await o.p.goto(U+'/docente'); await o.p.waitForTimeout(1500); t=await txt(o.p)
 reg('P-05', /Leo Aula/.test(t) && /Leo Dash/.test(t), 'docente ve Leo Aula y Leo Dash')
 await o.p.screenshot({path:'resultados/p05_docente.png'})
 // P-06 Leo Aula y Leo Dash cargan
 await o.p.goto(U+'/docente/aula'); await o.p.waitForTimeout(1500); const e1=o.p.errs.length; const ta=await txt(o.p)
 await o.p.goto(U+'/docente/panel'); await o.p.waitForTimeout(2500); const td=await txt(o.p)
 reg('P-06', /Leo Ideas|Aula/.test(ta) && /Leo Dash|Actividad|Estudiantes|Juegos de Aula/.test(td) && !o.p.errs.length, 'Leo Aula y Leo Dash cargan; errores de consola: '+o.p.errs.length)
 await o.p.screenshot({path:'resultados/p06_leodash.png'}); await o.ctx.close()
 // P-07 ruta U1 bloqueo progresivo
 o=await abrir(b); await o.p.goto(U+'/ruta'); await o.p.waitForTimeout(1500); t=await txt(o.p)
 const bloq=(t.match(/🔒/g)||[]).length
 reg('P-07', /Disponible · toca para empezar/.test(t) && bloq>=3, 'primera lección disponible y '+bloq+' lecciones bloqueadas')
 await o.p.screenshot({path:'resultados/p07_ruta.png', fullPage:false})
 // P-08 lección: error, pista y reintento; luego acierto y guardado
 await log()
 await o.p.getByText('Disponible · toca para empezar').first().click(); await o.p.waitForTimeout(1200)
 for (let i=0;i<4 && !(await o.p.getByRole('button',{name:'compró'}).count());i++){ await o.p.getByRole('button',{name:'Continuar'}).first().click(); await o.p.waitForTimeout(900) }
 await o.p.getByRole('button',{name:'compró'}).click(); await o.p.getByRole('button',{name:'Comprobar'}).click(); await o.p.waitForTimeout(900)
 t=await txt(o.p); const casi=/Ya casi/.test(t); await o.p.screenshot({path:'resultados/p08_ya_casi.png'})
 reg('P-08', casi && !/vidas|puntos? menos/i.test(t), 'respuesta incorrecta muestra "¡Ya casi!" con pista, sin penalización')
 const reint=o.p.getByRole('button',{name:/Intentar|reintentar|otra vez/i}).first(); let reOk=await reint.count()>0
 if (reOk) { await reint.click(); await o.p.waitForTimeout(700) }
 else { reOk=false }
 await o.p.getByRole('button',{name:'Javiera'}).click().catch(()=>{}); await o.p.getByRole('button',{name:'audífonos'}).click().catch(()=>{})
 await o.p.getByRole('button',{name:'Comprobar'}).click(); await o.p.waitForTimeout(900)
 t=await txt(o.p); await o.p.screenshot({path:'resultados/p09_fenomenal.png'})
 reg('P-09', /Fenomenal/.test(t), 'tras el reintento con respuesta correcta aparece "¡Fenomenal!" (opción de reintentar presente: '+reOk+')')
 const l=await log(); const gs=l.filter(x=>/game_sessions/.test(x)).length, gr=l.filter(x=>/game_responses/.test(x)).length
 reg('P-10', gs>=1 && gr>=1, 'solicitudes de guardado: game_sessions '+gs+', game_responses '+gr)
 await o.ctx.close()
 // P-11 rutas inválidas
 o=await abrir(b); await o.p.goto(U+'/xyz'); await o.p.waitForTimeout(1000); const a=new URL(o.p.url()).pathname
 await o.p.goto(U+'/juego/1/zzz/reglas'); await o.p.waitForTimeout(1000); const c=new URL(o.p.url()).pathname
 reg('P-11', a==='/inicio' && c==='/inicio', 'ruta inexistente -> '+a+'; texto de juego inválido -> '+c); await o.ctx.close()
 // P-12 Unidad 2
 o=await abrir(b); await o.p.goto(U+'/ruta/unidad-2'); await o.p.waitForTimeout(1800); t=await txt(o.p)
 reg('P-12', /Unidad 2/.test(t) && !o.p.errs.length, 'Unidad 2 carga; errores de consola: '+o.p.errs.length); await o.p.screenshot({path:'resultados/p12_u2.png'}); await o.ctx.close()
 // P-13 sin desborde horizontal
 const rutas=['/inicio','/ruta','/progreso','/ajustes','/leoia']; const bad=[]
 o=await abrir(b,{vp:{width:360,height:740}})
 for (const r of rutas){ await o.p.goto(U+r); await o.p.waitForTimeout(1200); const d=await o.p.evaluate(()=>document.documentElement.scrollWidth-window.innerWidth); if(d>1) bad.push(r+' (+'+d+'px)') }
 reg('P-13', bad.length===0, 'ancho 360 px; páginas con desborde horizontal: '+(bad.join(', ')||'ninguna')); await o.ctx.close()
 // P-14 cerrar sesión
 o=await abrir(b); await o.p.goto(U+'/inicio'); await o.p.waitForTimeout(1200)
 await o.p.setViewportSize({width:1280,height:800}); await o.p.getByText('Salir').first().click(); await o.p.waitForTimeout(800)
 const conf=await o.p.getByRole('button',{name:/Salir|Cerrar|Sí/i}).last(); try{ await conf.click({timeout:1500}) }catch(e){}
 await o.p.waitForTimeout(1500); const fin=new URL(o.p.url()).pathname
 reg('P-14', ['/','/login'].includes(fin), 'tras Salir la ruta es '+fin); await o.ctx.close()
 await b.close()
 require('fs').writeFileSync('resultados/resultados.json', JSON.stringify(R,null,1))
})()
