// Servidor estático con fallback SPA (como Netlify) + mock mínimo de Supabase
const http = require('http'), fs = require('fs'), path = require('path')
const DIST = process.env.DIST || path.join(__dirname,'dist-test')
const types = { '.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.png':'image/png', '.wav':'audio/wav', '.ico':'image/x-icon', '.svg':'image/svg+xml' }
http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split('?')[0])
  let f = path.join(DIST, p)
  if (!f.startsWith(DIST) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(DIST, 'index.html')
  res.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream' })
  fs.createReadStream(f).pipe(res)
}).listen(8201)

const rol = () => (global.ROL || 'alumno')
const user = { id: '11111111-1111-1111-1111-111111111111', email: 'ana@duocuc.cl', aud: 'authenticated', role: 'authenticated', user_metadata: { full_name: 'Ana Prueba' }, app_metadata: {} }
const log = []
http.createServer((req, res) => {
  const h = { 'access-control-allow-origin': '*', 'access-control-allow-headers': '*', 'access-control-allow-methods': '*', 'content-type': 'application/json' }
  if (req.method === 'OPTIONS') { res.writeHead(204, h); return res.end() }
  let body = ''
  req.on('data', c => body += c)
  req.on('end', () => {
    const u = req.url
    log.push(req.method + ' ' + u.split('?')[0])
    if (u.startsWith('/__log')) { res.writeHead(200, h); return res.end(JSON.stringify(log.splice(0))) }
    if (u.startsWith('/__delay/')) { global.DELAY = +u.split('/')[2]; res.writeHead(200, h); return res.end('{}') }
    if (u.startsWith('/__status/')) { global.STATUS = u.split('/')[2]; res.writeHead(200, h); return res.end('{}') }
    if (u.startsWith('/__rol/')) { global.ROL = u.split('/')[2]; res.writeHead(200, h); return res.end('{}') }
    if (u.startsWith('/auth/v1/user')) { res.writeHead(200, h); return res.end(JSON.stringify(user)) }
    if (u.startsWith('/auth/v1/logout')) { res.writeHead(204, h); return res.end() }
    if (u.startsWith('/rest/v1/profiles')) {
      const row = { id: user.id, full_name: 'Ana Prueba', rol: rol() }
      res.writeHead(200, h)
      return res.end(JSON.stringify(/pgrst.object/.test(req.headers.accept || '') ? row : [row]))
    }
    if (u.startsWith('/rest/v1/game_sessions') && req.method === 'POST') { res.writeHead(201, h); return res.end(JSON.stringify(/pgrst.object/.test(req.headers.accept || '') ? { id: 'sess-' + Date.now() } : [{ id: 'sess-' + Date.now() }])) }
    if (u.startsWith('/rest/v1/game_responses') && req.method === 'POST') { res.writeHead(201, h); return res.end('[]') }
    if (u.startsWith('/rest/v1/game_sessions') && req.method === 'GET' && /select=status/.test(u)) { const row = { status: global.STATUS || 'in_progress' }; res.writeHead(200, h); return res.end(JSON.stringify(/pgrst.object/.test(req.headers.accept || '') ? row : [row])) }
    if (u.startsWith('/__sesiones')) { global.SESIONES = body ? JSON.parse(body) : []; res.writeHead(200, h); return res.end('{}') }
    if (u.startsWith('/rest/v1/game_sessions') && req.method === 'GET' && global.SESIONES && global.SESIONES.length) { res.writeHead(200, h); return res.end(JSON.stringify(global.SESIONES)) }
    if (u.startsWith('/rest/v1/game_sessions') && req.method === 'GET' && global.DELAY) { return setTimeout(() => { res.writeHead(200, h); res.end('[]') }, global.DELAY) }
    if (u.startsWith('/rest/v1/')) { res.writeHead(200, h); return res.end('[]') }
    res.writeHead(404, h); res.end('{}')
  })
}).listen(54321)
console.log('listo')
