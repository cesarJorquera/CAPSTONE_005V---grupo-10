# Pruebas de extremo a extremo (e2e)

Verifican los flujos principales de Leo Perfecto en un navegador (Chromium) usando un servidor local que simula la autenticación y las tablas de Supabase. No se conectan a Supabase ni a Google, y no usan datos reales.

Casos cubiertos (P-01 a P-14): página pública, acceso protegido, roles, espacio docente, ruta de la Unidad 1, retroalimentación, guardado del avance, rutas inválidas, Unidad 2, ajuste a celular y cierre de sesión.

## Requisitos

- Node.js 22 y las dependencias del proyecto instaladas (`npm install`).
- Playwright: `npm install --no-save playwright` y luego `npx playwright install chromium`.

## Ejecución (PowerShell, desde la carpeta de la aplicación)

1. Construir la aplicación apuntando al servidor simulado:

   ```powershell
   $env:VUE_APP_SUPABASE_URL="http://localhost:54321"
   $env:VUE_APP_SUPABASE_ANON_KEY="clave-de-prueba"
   npx vue-cli-service build --dest tests/e2e/dist-test
   ```

2. En una terminal, iniciar el servidor simulado (sirve la app en el puerto 8201 y el mock en el 54321):

   ```powershell
   node tests/e2e/servidor-simulado.cjs
   ```

3. En otra terminal, ejecutar las pruebas:

   ```powershell
   node tests/e2e/pruebas.cjs
   ```

Cada caso imprime `OK` o `FALLA` con su detalle. Las capturas y `resultados.json` quedan en `resultados/`.

## Alcance y límites

El servidor simulado no implementa las funciones SQL del panel docente, por lo que Leo Dash muestra su mensaje de error controlado. Las verificaciones contra Supabase y Google reales se hacen aparte.
